
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const API_URL = "http://127.0.0.1:8000/navigate";

const translations = {
  en: {
    newChat: "New conversation", workspace: "WORKSPACE",
    assistant: "AI Care Assistant", resources: "Care resources",
    about: "About CareCompass", privacyTitle: "Your wellbeing matters",
    privacyText: "Share only what you feel comfortable sharing.",
    prototype: "AI health companion · Prototype",
    eyebrow: "PERSONALISED CARE NAVIGATION",
    welcome: "Your health journey,<br /><span>with a little more clarity.</span>",
    heroDescription: "Tell us what is concerning you. We'll help you explore sensible next steps and care options.",
    trust1: "Supportive guidance", trust2: "Multiple languages", trust3: "Care-focused",
    assistantHeading: "What would you like help with?",
    assistantSubheading: "Start with a question or choose a topic below.",
    online: "Ready", prompt1: "Headache", prompt2: "Stress & wellbeing",
    prompt3: "Find the right care", prompt4: "Sleep better",
    concernLabel: "Describe your concern",
    concernPlaceholder: "For example: I've had a mild headache since this morning...",
    privateNote: "Please avoid sharing identifying information.",
    locationLabel: "Location (optional)", locationPlaceholder: "City or area",
    responseLabel: "Response language",
    consent: "I understand this is informational support, not a medical diagnosis.",
    getGuidance: "Explore care options",
    disclaimer: "CareCompass AI does not diagnose, replace a clinician, or provide emergency services.",
    howTitle: "How it works", howSubtitle: "A simpler path to care",
    step1Title: "Tell us what's up", step1Text: "Describe your concern in your own words.",
    step2Title: "Explore guidance", step2Text: "Review general information and possible next steps.",
    step3Title: "Choose your next step", step3Text: "Consider suitable professional care when needed.",
    emergencyTitle: "Need urgent help?",
    emergencyText: "For a life-threatening emergency, contact your local emergency service immediately.",
    emergencyLink: "India emergency help ↗",
    wellbeingTitle: "A gentle reminder",
    wellbeingText: "Your concerns deserve attention. If something feels wrong or gets worse, reach out to a qualified healthcare professional.",
    resultHeading: "Your care guidance",
    resultSubheading: "General information to help you think about next steps.",
    nextStepsHeading: "Suggested next steps",
    resultNote: "This guidance is not a diagnosis. Seek professional care for personalised medical advice.",
    askAnother: "Ask another question ↗",
    resourcesTitle: "Explore care resources",
    resourcesDescription: "A few starting points for finding reliable health information and professional support.",
    resource1Title: "Find a hospital", resource1Text: "Explore hospitals and health facilities near your area.",
    resource1Link: "Explore government services ↗",
    resource2Title: "Consult a professional", resource2Text: "Consider speaking with a qualified doctor about persistent concerns.",
    resource2Link: "Explore eSanjeevani ↗",
    resource3Title: "Trusted health information", resource3Text: "Read public health information from an official source.",
    resource3Link: "Ministry of Health ↗",
    resource4Title: "Emergency support", resource4Text: "If there is immediate danger to life, get emergency help now.",
    resource4Link: "India emergency number 112 ↗",
    resourceFootnote: "Links are provided as starting points. Availability and eligibility may vary; verify details with the relevant service.",
    aboutTitle: "Care that feels easier to navigate.",
    aboutDescription: "CareCompass AI is a prototype for helping people organise health concerns, understand general information, and explore possible care options.",
    aboutCard1Title: "Clarity first", aboutCard1Text: "Make health information easier to approach, one question at a time.",
    aboutCard2Title: "Language matters", aboutCard2Text: "Switch between English, Hindi, and Hinglish for a more comfortable experience.",
    aboutCard3Title: "People before predictions", aboutCard3Text: "Encourage appropriate professional care instead of claiming to diagnose conditions.",
    importantTitle: "Important safety note",
    importantText: "This demonstration is not a medical device or emergency service. Do not use it as a substitute for qualified clinical advice. If you may be experiencing an emergency, contact local emergency services.",
    footerText: "Built with care · Prototype experience",
    validation: "Please describe your concern first.",
    consentError: "Please confirm that you understand this is informational support.",
    loading: "Preparing your response…",
    demoTitle: "Demo mode",
    demoText: "The backend could not be reached, so this is a demonstration message, not an AI assessment.",
    demoGuidance: "Write down your symptoms, when they began, and whether they are changing. For personal medical advice, contact a qualified healthcare professional.",
    urgentNotice: "If you have severe difficulty breathing, chest pain, signs of stroke, loss of consciousness, or another potentially life-threatening symptom, seek emergency help now. Do not wait for an AI response.",
    backendError: "The backend response could not be understood. Please try again.",
    backendUnavailable: "The backend is not connected. Showing a clearly labelled demo response.",
    languageChanged: "Language updated.", themeLight: "Light mode", themeDark: "Dark mode",
    pageAssistant: "AI Care Assistant", pageResources: "Care resources",
    pageAbout: "About CareCompass", newConversation: "New conversation started."
  },
  hi: {
    newChat: "नई बातचीत", workspace: "आपका कार्यक्षेत्र",
    assistant: "AI केयर असिस्टेंट", resources: "स्वास्थ्य सेवाएँ",
    about: "CareCompass के बारे में", privacyTitle: "आपकी भलाई ज़रूरी है",
    privacyText: "सिर्फ वही जानकारी साझा करें जिसमें आप सहज हों।",
    prototype: "AI स्वास्थ्य साथी · प्रोटोटाइप",
    eyebrow: "आपकी देखभाल के लिए मार्गदर्शन",
    welcome: "आपकी सेहत का सफ़र,<br /><span>अब थोड़ी और स्पष्टता के साथ।</span>",
    heroDescription: "अपनी परेशानी बताएँ। हम आपको अगले उचित कदम और उपलब्ध देखभाल विकल्प समझने में मदद करेंगे।",
    trust1: "सहायक मार्गदर्शन", trust2: "कई भाषाएँ", trust3: "देखभाल पर केंद्रित",
    assistantHeading: "आप किस विषय में मदद चाहते हैं?",
    assistantSubheading: "अपना सवाल लिखें या नीचे कोई विषय चुनें।",
    online: "तैयार", prompt1: "सिरदर्द", prompt2: "तनाव और मन की सेहत",
    prompt3: "सही देखभाल चुनें", prompt4: "बेहतर नींद",
    concernLabel: "अपनी परेशानी बताएँ",
    concernPlaceholder: "उदाहरण: आज सुबह से मुझे हल्का सिरदर्द है...",
    privateNote: "अपनी पहचान बताने वाली जानकारी साझा न करें।",
    locationLabel: "स्थान (वैकल्पिक)", locationPlaceholder: "शहर या इलाका",
    responseLabel: "जवाब की भाषा",
    consent: "मैं समझता/समझती हूँ कि यह सामान्य जानकारी है, मेडिकल निदान नहीं।",
    getGuidance: "देखभाल के विकल्प देखें",
    disclaimer: "CareCompass AI बीमारी का निदान नहीं करता और डॉक्टर या आपातकालीन सेवा का विकल्प नहीं है।",
    howTitle: "यह कैसे काम करता है", howSubtitle: "देखभाल पाने का आसान तरीका",
    step1Title: "अपनी परेशानी बताएँ", step1Text: "अपनी समस्या अपने शब्दों में लिखें।",
    step2Title: "मार्गदर्शन समझें", step2Text: "सामान्य जानकारी और अगले संभावित कदम देखें।",
    step3Title: "अगला कदम चुनें", step3Text: "ज़रूरत पड़ने पर योग्य स्वास्थ्य विशेषज्ञ से संपर्क करें।",
    emergencyTitle: "तुरंत मदद चाहिए?",
    emergencyText: "जान को खतरा होने पर तुरंत स्थानीय आपातकालीन सेवा से संपर्क करें।",
    emergencyLink: "भारत में आपातकालीन सहायता ↗",
    wellbeingTitle: "एक ज़रूरी याद दिलाना",
    wellbeingText: "आपकी परेशानी ध्यान देने योग्य है। समस्या बढ़ने पर योग्य स्वास्थ्य विशेषज्ञ से संपर्क करें।",
    resultHeading: "आपके लिए देखभाल संबंधी जानकारी",
    resultSubheading: "अगले कदम समझने के लिए सामान्य जानकारी।",
    nextStepsHeading: "अगले संभावित कदम",
    resultNote: "यह मेडिकल निदान नहीं है। व्यक्तिगत सलाह के लिए स्वास्थ्य विशेषज्ञ से संपर्क करें।",
    askAnother: "दूसरा सवाल पूछें ↗",
    resourcesTitle: "स्वास्थ्य सेवाएँ देखें",
    resourcesDescription: "विश्वसनीय स्वास्थ्य जानकारी और पेशेवर सहायता पाने के लिए कुछ शुरुआती विकल्प।",
    resource1Title: "अस्पताल खोजें", resource1Text: "अपने इलाके में अस्पताल और स्वास्थ्य सुविधाएँ देखें।",
    resource1Link: "सरकारी सेवाएँ देखें ↗",
    resource2Title: "स्वास्थ्य विशेषज्ञ से सलाह लें", resource2Text: "लगातार परेशानी होने पर योग्य डॉक्टर से बात करें।",
    resource2Link: "eSanjeevani देखें ↗",
    resource3Title: "विश्वसनीय स्वास्थ्य जानकारी", resource3Text: "आधिकारिक स्रोत से सार्वजनिक स्वास्थ्य जानकारी पढ़ें।",
    resource3Link: "स्वास्थ्य मंत्रालय ↗",
    resource4Title: "आपातकालीन सहायता", resource4Text: "जान को तत्काल खतरा होने पर तुरंत मदद लें।",
    resource4Link: "भारत का आपातकालीन नंबर 112 ↗",
    resourceFootnote: "ये लिंक शुरुआती जानकारी के लिए हैं। उपलब्धता और पात्रता संबंधित सेवा से जाँचें।",
    aboutTitle: "स्वास्थ्य संबंधी अगले कदम समझना अब आसान।",
    aboutDescription: "CareCompass AI एक प्रोटोटाइप है, जो स्वास्थ्य संबंधी चिंताओं को व्यवस्थित करने और देखभाल के विकल्प समझने में मदद करने के लिए बनाया गया है।",
    aboutCard1Title: "स्पष्ट जानकारी", aboutCard1Text: "एक-एक सवाल के ज़रिए स्वास्थ्य जानकारी को समझना आसान बनाएँ।",
    aboutCard2Title: "भाषा का महत्व", aboutCard2Text: "अपनी सुविधा के अनुसार हिंदी, अंग्रेज़ी या Hinglish चुनें।",
    aboutCard3Title: "सही देखभाल सबसे पहले", aboutCard3Text: "बीमारी का निदान करने का दावा करने के बजाय योग्य विशेषज्ञ की सलाह को प्राथमिकता दें।",
    importantTitle: "महत्वपूर्ण सुरक्षा सूचना",
    importantText: "यह मेडिकल उपकरण या आपातकालीन सेवा नहीं है। इसे योग्य डॉक्टर की सलाह के विकल्प के रूप में इस्तेमाल न करें। आपातकाल में स्थानीय आपातकालीन सेवा से संपर्क करें।",
    footerText: "ध्यान से बनाया गया · प्रोटोटाइप",
    validation: "कृपया पहले अपनी परेशानी बताएँ।",
    consentError: "कृपया पुष्टि करें कि आप समझते हैं कि यह सामान्य जानकारी है।",
    loading: "जवाब तैयार किया जा रहा है…",
    demoTitle: "डेमो मोड",
    demoText: "बैकएंड से संपर्क नहीं हो सका। यह सिर्फ डेमो संदेश है, AI द्वारा किया गया आकलन नहीं।",
    demoGuidance: "अपने लक्षण, उनके शुरू होने का समय और उनमें बदलाव नोट करें। व्यक्तिगत सलाह के लिए योग्य स्वास्थ्य विशेषज्ञ से संपर्क करें।",
    urgentNotice: "साँस लेने में गंभीर परेशानी, सीने में दर्द, स्ट्रोक के संकेत, बेहोशी या जानलेवा लक्षण होने पर तुरंत आपातकालीन मदद लें। AI के जवाब का इंतज़ार न करें।",
    backendError: "बैकएंड का जवाब समझ नहीं आया। कृपया दोबारा कोशिश करें।",
    backendUnavailable: "बैकएंड कनेक्ट नहीं है। स्पष्ट रूप से बताए गए डेमो जवाब को दिखाया जा रहा है।",
    languageChanged: "भाषा बदल दी गई है।", themeLight: "लाइट मोड", themeDark: "डार्क मोड",
    pageAssistant: "AI केयर असिस्टेंट", pageResources: "स्वास्थ्य सेवाएँ",
    pageAbout: "CareCompass के बारे में", newConversation: "नई बातचीत शुरू हुई।"
  },
  hinglish: {
    newChat: "New conversation", workspace: "WORKSPACE",
    assistant: "AI Care Assistant", resources: "Care resources",
    about: "CareCompass ke baare mein", privacyTitle: "Aapki wellbeing zaroori hai",
    privacyText: "Sirf wahi information share karein jisme aap comfortable hon.",
    prototype: "AI health companion · Prototype",
    eyebrow: "PERSONALISED CARE NAVIGATION",
    welcome: "Aapki health journey,<br /><span>ab thodi aur clarity ke saath.</span>",
    heroDescription: "Apni concern batao. Hum aapko possible next steps aur care options explore karne mein help karenge.",
    trust1: "Helpful guidance", trust2: "Multiple languages", trust3: "Care-focused",
    assistantHeading: "Aapko kis cheez mein help chahiye?",
    assistantSubheading: "Apna question likho ya neeche koi topic choose karo.",
    online: "Ready", prompt1: "Headache", prompt2: "Stress & wellbeing",
    prompt3: "Right care find karein", prompt4: "Better sleep",
    concernLabel: "Apni concern describe karein",
    concernPlaceholder: "Example: Aaj morning se halka headache ho raha hai...",
    privateNote: "Apni identity reveal karne wali information share na karein.",
    locationLabel: "Location (optional)", locationPlaceholder: "City ya area",
    responseLabel: "Response language",
    consent: "Main samajhta/samajhti hoon ki ye informational support hai, medical diagnosis nahi.",
    getGuidance: "Care options explore karein",
    disclaimer: "CareCompass AI diagnosis nahi karta aur doctor ya emergency service ka replacement nahi hai.",
    howTitle: "Ye kaise kaam karta hai", howSubtitle: "Care tak pahunchne ka simple way",
    step1Title: "Apni concern batao", step1Text: "Apni problem apne words mein describe karein.",
    step2Title: "Guidance explore karein", step2Text: "General information aur possible next steps dekhein.",
    step3Title: "Next step choose karein", step3Text: "Zaroorat padne par qualified health professional se baat karein.",
    emergencyTitle: "Urgent help chahiye?",
    emergencyText: "Life-threatening emergency mein immediately local emergency service contact karein.",
    emergencyLink: "India emergency help ↗",
    wellbeingTitle: "Ek gentle reminder",
    wellbeingText: "Aapki concern important hai. Problem badhne par qualified healthcare professional se contact karein.",
    resultHeading: "Aapke care options",
    resultSubheading: "Next steps samajhne ke liye general information.",
    nextStepsHeading: "Suggested next steps",
    resultNote: "Ye diagnosis nahi hai. Personal medical advice ke liye qualified professional se baat karein.",
    askAnother: "Ek aur question poochhein ↗",
    resourcesTitle: "Care resources explore karein",
    resourcesDescription: "Reliable health information aur professional support ke liye kuch starting points.",
    resource1Title: "Hospital find karein", resource1Text: "Apne area ke hospitals aur health facilities explore karein.",
    resource1Link: "Government services dekhein ↗",
    resource2Title: "Professional se consult karein", resource2Text: "Persistent concerns ke liye qualified doctor se baat karein.",
    resource2Link: "eSanjeevani explore karein ↗",
    resource3Title: "Trusted health information", resource3Text: "Official source se public health information padhein.",
    resource3Link: "Ministry of Health ↗",
    resource4Title: "Emergency support", resource4Text: "Life ko immediate danger ho toh emergency help lein.",
    resource4Link: "India emergency number 112 ↗",
    resourceFootnote: "Ye links starting points hain. Availability aur eligibility relevant service se verify karein.",
    aboutTitle: "Care options samajhna ab thoda easier.",
    aboutDescription: "CareCompass AI ek prototype hai jo health concerns organise karne aur possible care options explore karne mein help karta hai.",
    aboutCard1Title: "Clarity first", aboutCard1Text: "Health information ko step-by-step samajhna easier banayein.",
    aboutCard2Title: "Language matters", aboutCard2Text: "English, Hindi aur Hinglish mein apni comfortable language choose karein.",
    aboutCard3Title: "People before predictions", aboutCard3Text: "Diagnosis claim karne ke bajaye qualified professional ki care ko encourage karein.",
    importantTitle: "Important safety note",
    importantText: "Ye medical device ya emergency service nahi hai. Qualified doctor ki advice ke replacement ke roop mein use na karein. Emergency mein local emergency services contact karein.",
    footerText: "Built with care · Prototype experience",
    validation: "Please pehle apni concern describe karein.",
    consentError: "Please confirm karein ki aap samajhte hain ye informational support hai.",
    loading: "Response prepare ho raha hai…",
    demoTitle: "Demo mode",
    demoText: "Backend connect nahi ho saka. Ye sirf demo message hai, AI assessment nahi.",
    demoGuidance: "Apne symptoms, kab start hue aur kaise change ho rahe hain, note karein. Personal medical advice ke liye qualified health professional se contact karein.",
    urgentNotice: "Severe breathing problem, chest pain, stroke signs, unconsciousness ya life-threatening symptoms mein immediately emergency help lein. AI response ka wait na karein.",
    backendError: "Backend response samajh nahi aaya. Please dobara try karein.",
    backendUnavailable: "Backend connected nahi hai. Clearly labelled demo response show ho raha hai.",
    languageChanged: "Language updated.", themeLight: "Light mode", themeDark: "Dark mode",
    pageAssistant: "AI Care Assistant", pageResources: "Care resources",
    pageAbout: "About CareCompass", newConversation: "New conversation started."
  }
};

let currentLanguage = "en";
let toastTimeout;
let conversationHistory = [];

function t(key) {
  return translations[currentLanguage]?.[key] ?? translations.en[key] ?? key;
}

function applyTranslations() {
  document.documentElement.lang = currentLanguage === "hi" ? "hi" : "en";

  $$("[data-i18n]").forEach((element) => {
    const key = element.dataset.i18n;
    const translated = t(key);
    if (translated !== key) element.innerHTML = translated;
  });

  $$("[data-i18n-placeholder]").forEach((element) => {
    element.placeholder = t(element.dataset.i18nPlaceholder);
  });

  $("#theme-label").textContent =
    document.documentElement.dataset.theme === "dark" ? t("themeLight") : t("themeDark");

  updateCount();
  updatePageTitle();
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove("show"), 2600);
}

function applyTheme(theme) {
  const safeTheme = theme === "light" ? "light" : "dark";
  document.documentElement.dataset.theme = safeTheme;
  $("#theme-icon").textContent = safeTheme === "dark" ? "☀️" : "🌙";
  $("#theme-label").textContent = safeTheme === "dark" ? t("themeLight") : t("themeDark");
  $("#theme-toggle").setAttribute("aria-label", $("#theme-label").textContent);

  try {
    localStorage.setItem("carecompass-theme", safeTheme);
  } catch {
    // Theme still works for this session when storage is unavailable.
  }
}

$("#theme-toggle").addEventListener("click", () => {
  const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  applyTheme(next);
});

try {
  applyTheme(localStorage.getItem("carecompass-theme") || "dark");
} catch {
  applyTheme("dark");
}

$("#language-select").addEventListener("change", (event) => {
  currentLanguage = event.target.value;
  $("#preferred-language").value = currentLanguage;
  applyTranslations();
  showToast(t("languageChanged"));
});

$("#preferred-language").addEventListener("change", (event) => {
  currentLanguage = event.target.value;
  $("#language-select").value = currentLanguage;
  applyTranslations();
});

function updateCount() {
  const length = $("#concern").value.length;
  $("#char-count").textContent = `${length} / 1500`;
}

$("#concern").addEventListener("input", updateCount);

const pageInfo = {
  assistant: { page: "assistant-page", title: "pageAssistant" },
  resources: { page: "resources-page", title: "pageResources" },
  about: { page: "about-page", title: "pageAbout" }
};

function updatePageTitle() {
  const active = $(".nav-link.active");
  const tab = active?.dataset.tab || "assistant";
  $("#page-title").textContent = t(pageInfo[tab]?.title || "pageAssistant");
}

function showTab(tabName) {
  if (!pageInfo[tabName]) return;

  $$(".nav-link").forEach((button) => {
    const active = button.dataset.tab === tabName;
    button.classList.toggle("active", active);
    button.setAttribute("aria-current", active ? "page" : "false");
  });

  $$(".tab-page").forEach((page) => page.classList.remove("active"));
  $(`#${pageInfo[tabName].page}`).classList.add("active");

  updatePageTitle();
  $("#sidebar").classList.remove("open");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

$$(".nav-link").forEach((button) => {
  button.addEventListener("click", () => showTab(button.dataset.tab));
});

$("#mobile-menu").addEventListener("click", () => {
  $("#sidebar").classList.toggle("open");
});

document.addEventListener("click", (event) => {
  if (
    window.innerWidth <= 700 &&
    $("#sidebar").classList.contains("open") &&
    !$("#sidebar").contains(event.target) &&
    !$("#mobile-menu").contains(event.target)
  ) {
    $("#sidebar").classList.remove("open");
  }
});

$$(".prompt-chip").forEach((button) => {
  button.addEventListener("click", () => {
    $("#concern").value = button.dataset.prompt;
    updateCount();
    $("#concern").focus();
    $("#concern-form").scrollIntoView({ behavior: "smooth", block: "center" });
  });
});

function resetConversation() {
  conversationHistory = [];
  $("#concern").value = "";
  $("#location").value = "";
  $("#privacy-check").checked = false;
  $("#form-message").textContent = "";
  $("#results-panel").classList.add("hidden");
  $("#result-summary").textContent = "";
  $("#triage-content").textContent = "";
  $("#resource-list").replaceChildren();
  updateCount();
  showTab("assistant");
  showToast(t("newConversation"));
}

$("#new-chat").addEventListener("click", resetConversation);
$("#ask-another").addEventListener("click", () => {
  $("#concern").value = "";
  updateCount();
  $("#concern").focus();
  $("#concern-form").scrollIntoView({ behavior: "smooth", block: "center" });
});

function addResource(text) {
  const item = document.createElement("div");
  item.className = "resource-item";
  item.textContent = text;
  $("#resource-list").appendChild(item);
}

function showResult(summary, guidance, options = []) {
  $("#result-summary").textContent = summary;
  $("#triage-content").textContent = guidance;
  $("#resource-list").replaceChildren();
  options.forEach(addResource);
  $("#results-panel").classList.remove("hidden");
  $("#results-panel").scrollIntoView({ behavior: "smooth", block: "start" });
}

function getDemoResult() {
  const concern = $("#concern").value.trim();
  const urgentTerms = [
    "chest pain", "can't breathe", "cannot breathe", "difficulty breathing",
    "stroke", "unconscious", "severe bleeding", "not breathing",
    "सीने में दर्द", "साँस नहीं", "बेहोश", "स्ट्रोक", "सांस लेने में परेशानी"
  ];
  const potentiallyUrgent = urgentTerms.some((term) =>
    concern.toLowerCase().includes(term)
  );

  const summary = `${t("demoTitle")}: ${t("demoText")}`;
  const guidance = potentiallyUrgent
    ? t("urgentNotice")
    : t("demoGuidance");

  const options = potentiallyUrgent
    ? [t("emergencyText"), t("disclaimer")]
    : [
        t("step1Text"),
        t("step2Text"),
        t("step3Text")
      ];

  showResult(summary, guidance, options);
}

function extractResponse(data) {
  if (!data || typeof data !== "object") return null;

  // Support common response shapes. Adapt these keys to your FastAPI schema.
  const summary =
    data.summary ?? data.message ?? data.response ?? data.answer ?? "";
  const guidance =
    data.guidance ?? data.advice ?? data.result ?? data.content ?? "";

  const options = Array.isArray(data.resources)
    ? data.resources.map((item) => {
        if (typeof item === "string") return item;
        if (item && typeof item === "object") {
          return item.name || item.title || item.description || "";
        }
        return "";
      }).filter(Boolean)
    : Array.isArray(data.next_steps)
      ? data.next_steps.map(String)
      : [];

  if (typeof summary !== "string" || typeof guidance !== "string") return null;
  if (!summary && !guidance) return null;

  return { summary: summary || t("resultHeading"), guidance, options };
}

$("#concern-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  $("#form-message").textContent = "";

  const concern = $("#concern").value.trim();
  if (!concern) {
    $("#form-message").textContent = t("validation");
    $("#concern").focus();
    return;
  }

  if (!$("#privacy-check").checked) {
    $("#form-message").textContent = t("consentError");
    $("#privacy-check").focus();
    return;
  }

  const button = $("#analyze-btn");
  const originalButtonText = button.innerHTML;
  button.disabled = true;
  button.querySelector("[data-i18n]").textContent = t("loading");

  const language = $("#preferred-language").value;
  const location = $("#location").value.trim();

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        user_input: concern,
        language,
        location,
        conversation_history: conversationHistory
      })
    });

    if (!response.ok) {
      throw new Error(`Backend returned ${response.status}`);
    }

    const data = await response.json();
    const parsed = extractResponse(data);

    if (!parsed) {
      $("#form-message").textContent = t("backendError");
      return;
    }

    conversationHistory.push(
      { role: "user", content: concern },
      { role: "assistant", content: parsed.guidance }
    );

    showResult(parsed.summary, parsed.guidance, parsed.options);
  } catch (error) {
    console.warn("CareCompass backend is unavailable:", error);
    showToast(t("backendUnavailable"));
    getDemoResult();
  } finally {
    button.disabled = false;
    button.innerHTML = originalButtonText;
    applyTranslations();
  }
});

applyTranslations();
showTab("assistant");
updateCount();
